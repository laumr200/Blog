import mongoose from "mongoose";

export const  connectDB = async () =>{

    await mongoose.connect('mongodb+srv://lauracmoye:Morumba49*@cluster0.x52nyl4.mongodb.net/food-del').then(()=>console.log("DB Connected"));
   
}

