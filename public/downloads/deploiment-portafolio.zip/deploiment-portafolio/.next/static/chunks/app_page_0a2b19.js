(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_0a2b19.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_0a2b19.js",
  "chunks": [
    "static/chunks/_0a7d22._.js",
    "static/chunks/node_modules_next_cedaea._.js",
    "static/chunks/node_modules_motion_dist_es_67d5e4._.js"
  ],
  "source": "dynamic"
});
