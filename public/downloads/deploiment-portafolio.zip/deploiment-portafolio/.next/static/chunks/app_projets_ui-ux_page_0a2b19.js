(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_projets_ui-ux_page_0a2b19.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_projets_ui-ux_page_0a2b19.js",
  "chunks": [
    "static/chunks/_73eee3._.js"
  ],
  "source": "dynamic"
});
