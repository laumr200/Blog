(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_projets_medical-staff_page_0a2b19.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_projets_medical-staff_page_0a2b19.js",
  "chunks": [
    "static/chunks/_305b84._.js"
  ],
  "source": "dynamic"
});
