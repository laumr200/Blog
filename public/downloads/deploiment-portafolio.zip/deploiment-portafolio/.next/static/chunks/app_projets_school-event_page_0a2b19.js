(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_projets_school-event_page_0a2b19.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_projets_school-event_page_0a2b19.js",
  "chunks": [
    "static/chunks/_59b4fc._.js"
  ],
  "source": "dynamic"
});
